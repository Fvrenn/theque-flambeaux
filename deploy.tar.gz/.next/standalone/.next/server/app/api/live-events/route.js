var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/live-events/route.js")
R.c("server/chunks/[root-of-the-server]__09hf~zu._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_live-events_route_actions_0rx4xbq.js")
R.m(41054)
module.exports=R.m(41054).exports
