module.exports=[89669,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_live-events_route_actions_0rx4xbq.js.map