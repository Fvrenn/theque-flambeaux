module.exports=[28885,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_ranking_page_actions_0x51lor.js.map