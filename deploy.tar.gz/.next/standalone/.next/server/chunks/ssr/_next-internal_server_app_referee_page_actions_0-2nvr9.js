module.exports=[5722,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_referee_page_actions_0-2nvr9.js.map