globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/gOB7IzidoISussOsefcSu/_buildManifest.js",
    "static/gOB7IzidoISussOsefcSu/_ssgManifest.js",
    "static/gOB7IzidoISussOsefcSu/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ze4gu236oq96.js",
    "static/chunks/0~-sl6f.l6gsn.js",
    "static/chunks/0q-l3f9z4dgy5.js",
    "static/chunks/145vixdm8_8jr.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0bogtdbh.dcu1.js",
    "static/chunks/turbopack-06__yed7v06-d.js"
  ]
};
